rootProject.name = "AdminCore"
