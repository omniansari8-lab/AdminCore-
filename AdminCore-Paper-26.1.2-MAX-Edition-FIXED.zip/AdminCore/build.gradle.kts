plugins { java }
group = "com.example"
version = "MAX"
repositories { mavenCentral(); maven("https://repo.papermc.io/repository/maven-public/") }
dependencies { compileOnly("io.papermc.paper:paper-api:26.1.2.build.62-stable") }
java { toolchain { languageVersion.set(JavaLanguageVersion.of(25)) } }
