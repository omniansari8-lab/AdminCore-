# AdminCore (Paper 26.1.2 Plugin)

A professional, high-performance, admin-only utility and moderation suite built specifically for **Paper 26.1.2** (`io.papermc.paper:paper-api:26.1.2.build.62-stable`) and **Java 25**.

## ✨ Key Features & Commands

### 🛡️ Core Moderation & Staff Tools
* **`/mod`** (`admincore.admin`) — Instantly toggles **Vanish** (stealth invisibility), **God Mode** (invulnerability), and **Flight** simultaneously with a single command.
* **`/vanish`** (`admincore.vanish.self`) — Hides you completely from non-admin players and joins.
* **`/god`** (`admincore.god.self`) — Enables absolute invulnerability and infinite hunger.
* **`/freeze <player>`** (`admincore.freeze.player`) — Locks a player in place and blocks block breaking/placing.
* **`/freezeall`** (`admincore.freeze.all`) — Toggles global server freeze for all non-admin players.
* **`/lockdown`** (`admincore.lockdown.toggle`) — Restricts server logins to administrators only with a custom MiniMessage kick screen.

### 🌌 Space Control Hub (Animated GUI)
* **`/ac` or `/agui`** (`admincore.admin`) — Opens the interactive 54-slot **AdminCore Space Hub**.
  * Complete with an immersive, animated cosmic background featuring swirling **Portal** and **End Rod** particles while the GUI is open.
  * Instant toggles for weather, time, server lockdown, muting, freezing, and spawning the Admin Boss Trial event.

### ⚡ Custom Admin Artifacts & Items
* **`/ac item all`** — Grants the legendary admin toolset:
  * **⚡ Admin Staff of Smite (Breeze Rod):** Right-click to strike lightning up to 60 blocks away.
  * **🔨 Admin Banish Mace (Mace):** One-shot hostile mobs or launch players skyward with explosion effects.
  * **🌀 Admin Phase Orb (Echo Shard):** Crosshair teleportation up to 100 blocks with zero fall damage.
* **`/repair`** — Restores held item durability to maximum.
* **`/unbreakable`** — Toggles the unbreakable tag on held items.
* **`/rename <Name>`** — Renames held items using full MiniMessage RGB and gradient formatting.

### 🧹 Diagnostics, Chat & World Control
* **`/serverinfo`** — Displays live 1-minute TPS and JVM memory usage.
* **`/ping [player]`** — Checks network latency in milliseconds.
* **`/mutechat`** — Toggles global chat muting.
* **`/clearchat`** — Wipes public chat history.
* **`/butcher`** — Clears hostile mobs.
* **`/clearitems`** — Removes ground items to boost server performance.

## 🛠️ Build & Installation
1. **Requirements:** Java 25 JDK & Paper 26.1.2 server.
2. **Build:** Run `mvn clean package`, `gradle build`, or use the included `build.bat` or `build.sh` scripts.
3. **Install:** Place `AdminCore-2.1.0.jar` into your server's `plugins/` folder and restart.
