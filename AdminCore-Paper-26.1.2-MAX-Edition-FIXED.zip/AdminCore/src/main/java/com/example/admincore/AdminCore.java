package com.example.admincore;

import com.example.admincore.animation.SpaceAnimationManager;
import com.example.admincore.command.StandaloneCommandExecutor;
import com.example.admincore.gui.AdminGui;
import com.example.admincore.gui.GuiListener;
import com.example.admincore.item.AdminItemManager;
import com.example.admincore.listener.AdminListener;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class AdminCore extends JavaPlugin {
    private final Set<UUID> vanishedAdmins = new HashSet<>();
    private final Set<UUID> godModeAdmins = new HashSet<>();
    private boolean serverLockdown = false;

    private AdminItemManager itemManager;
    private AdminGui adminGui;
    private SpaceAnimationManager animationManager;

    @Override
    public void onEnable() {
        this.itemManager = new AdminItemManager(this);
        this.adminGui = new AdminGui(this);
        this.animationManager = new SpaceAnimationManager(this);
        
        animationManager.startAnimations();

        StandaloneCommandExecutor executor = new StandaloneCommandExecutor(this);
        List<String> commands = List.of("ac", "mod", "vanish", "god", "lockdown", "freeze", "heal", "fly", "gmc", "smite", "butcher", "help");
        for (String cmd : commands) {
            PluginCommand pCmd = getCommand(cmd);
            if (pCmd != null) pCmd.setExecutor(executor);
        }

        Bukkit.getPluginManager().registerEvents(new AdminListener(this), this);
        Bukkit.getPluginManager().registerEvents(new GuiListener(this), this);

        getLogger().info("AdminCore Maximum Edition (Animations + Artifacts) Enabled!");
    }

    public boolean toggleVanish(Player p) {
        if (vanishedAdmins.remove(p.getUniqueId())) {
            for (Player o : Bukkit.getOnlinePlayers()) o.showPlayer(this, p);
            return false;
        } else {
            vanishedAdmins.add(p.getUniqueId());
            for (Player o : Bukkit.getOnlinePlayers()) if (!o.hasPermission("admincore.admin")) o.hidePlayer(this, p);
            return true;
        }
    }

    public boolean toggleGodMode(Player p) {
        if (godModeAdmins.remove(p.getUniqueId())) return false;
        godModeAdmins.add(p.getUniqueId());
        return true;
    }

    public void toggleLockdown() { serverLockdown = !serverLockdown; }
    public boolean isServerLockdown() { return serverLockdown; }
    public AdminGui getAdminGui() { return adminGui; }
    public AdminItemManager getItemManager() { return itemManager; }
    public Set<UUID> getGodModeAdmins() { return godModeAdmins; }
    public Set<UUID> getVanishedAdmins() { return vanishedAdmins; }
}
