package com.example.admincore.item;

import com.example.admincore.AdminCore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class AdminItemManager {
    private final NamespacedKey key;
    public AdminItemManager(AdminCore plugin) { this.key = new NamespacedKey(plugin, "artifact"); }

    public void giveAllArtifacts(Player p) {
        p.getInventory().addItem(
            createArtifact(Material.BREEZE_ROD, "⚡ Staff of Smite", "smite"),
            createArtifact(Material.MACE, "🔨 Banish Mace", "banish"),
            createArtifact(Material.ECHO_SHARD, "🌀 Phase Orb", "phase"),
            createArtifact(Material.BOW, "🌌 Black Hole Bow", "blackhole"),
            createArtifact(Material.NETHERITE_SWORD, "💥 Supernova Sword", "supernova"),
            createArtifact(Material.TRIDENT, "☄ Gravity Wand", "gravity"),
            createArtifact(Material.SHIELD, "🛡 Nebula Shield", "nebula")
        );
    }

    private ItemStack createArtifact(Material mat, String name, String id) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, NamedTextColor.LIGHT_PURPLE));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        return item;
    }

    public String getArtifactId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }
}
