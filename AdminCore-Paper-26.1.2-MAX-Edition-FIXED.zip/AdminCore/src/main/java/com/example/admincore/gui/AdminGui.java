package com.example.admincore.gui;

import com.example.admincore.AdminCore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class AdminGui {

    private final AdminCore plugin;
    private final Set<UUID> openGuis = new HashSet<>();
    private int tickColor = 0;

    public AdminGui(AdminCore plugin) {
        this.plugin = plugin;
        startGuiAnimation();
    }

    public boolean hasGuiOpen(Player p) {
        return openGuis.contains(p.getUniqueId());
    }

    public void removeGui(Player p) {
        openGuis.remove(p.getUniqueId());
    }

    private void startGuiAnimation() {
        new BukkitRunnable() {
            Material[] colors = {Material.PURPLE_STAINED_GLASS_PANE, Material.MAGENTA_STAINED_GLASS_PANE, Material.BLUE_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE};
            @Override
            public void run() {
                tickColor = (tickColor + 1) % colors.length;
                for (UUID uuid : openGuis) {
                    Player p = Bukkit.getPlayer(uuid);
                    if (p != null && p.getOpenInventory().getTopInventory().getHolder() instanceof AdminMenuHolder holder) {
                        Inventory inv = p.getOpenInventory().getTopInventory();
                        ItemStack glass = createButton(colors[tickColor], "§d🌌 Space Hub", NamedTextColor.DARK_PURPLE, List.of("Animated Cosmic GUI"));
                        for (int i = 0; i < inv.getSize(); i++) {
                            if (inv.getItem(i) != null && inv.getItem(i).getType().name().contains("GLASS_PANE")) {
                                inv.setItem(i, glass);
                            }
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 5L);
    }

    public void openMainMenu(Player admin) {
        AdminMenuHolder holder = new AdminMenuHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, Component.text("✨ AdminCore Space Hub ✨", NamedTextColor.DARK_PURPLE).decoration(TextDecoration.BOLD, true));
        holder.setInventory(inv);

        boolean vanished = plugin.getVanishedAdmins().contains(admin.getUniqueId());
        boolean god = plugin.getGodModeAdmins().contains(admin.getUniqueId());

        inv.setItem(10, createButton(vanished ? Material.ENDER_EYE : Material.ENDER_PEARL, "Toggle Vanish", NamedTextColor.AQUA, List.of("Current: " + vanished)));
        inv.setItem(11, createButton(god ? Material.ENCHANTED_GOLDEN_APPLE : Material.GOLDEN_APPLE, "Toggle God Mode", NamedTextColor.GOLD, List.of("Current: " + god)));
        inv.setItem(12, createButton(Material.FEATHER, "Toggle Flight", NamedTextColor.YELLOW, List.of("Toggle survival flight")));
        inv.setItem(13, createButton(Material.NETHER_STAR, "Cycle Gamemode", NamedTextColor.LIGHT_PURPLE, List.of("Creative / Spectator / Survival")));
        inv.setItem(14, createButton(Material.BREEZE_ROD, "Claim All 7 Artifacts", NamedTextColor.GOLD, List.of("Smite, Banish, Phase, BlackHole,", "Supernova, Gravity, Nebula")));
        inv.setItem(15, createButton(Material.IRON_DOOR, "Toggle Lockdown", NamedTextColor.RED, List.of("Blocks non-admins")));
        inv.setItem(16, createButton(Material.TNT, "Butcher Monsters", NamedTextColor.DARK_RED, List.of("Kill all hostiles")));
        
        ItemStack filler = createButton(Material.BLACK_STAINED_GLASS_PANE, " ", NamedTextColor.BLACK, List.of());
        for (int i = 0; i < inv.getSize(); i++) {
            if (inv.getItem(i) == null) inv.setItem(i, filler);
        }

        admin.openInventory(inv);
        openGuis.add(admin.getUniqueId());
        admin.playSound(admin.getLocation(), Sound.BLOCK_PORTAL_AMBIENT, 0.6f, 1.5f);
    }

    private ItemStack createButton(Material mat, String title, NamedTextColor color, List<String> loreLines) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(title, color).decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, true));
        meta.lore(loreLines.stream().map(line -> Component.text(line, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)).toList());
        item.setItemMeta(meta);
        return item;
    }

    public static class AdminMenuHolder implements InventoryHolder {
        private Inventory inventory;
        public void setInventory(Inventory inventory) { this.inventory = inventory; }
        @Override public @NotNull Inventory getInventory() { return inventory; }
    }
}
