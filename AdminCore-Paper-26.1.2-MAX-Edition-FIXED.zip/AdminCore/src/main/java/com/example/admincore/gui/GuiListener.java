package com.example.admincore.gui;

import com.example.admincore.AdminCore;
import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;

public class GuiListener implements Listener {
    private final AdminCore plugin;
    public GuiListener(AdminCore plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof AdminGui.AdminMenuHolder)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player admin) || !admin.hasPermission("admincore.admin")) return;

        switch (event.getRawSlot()) {
            case 10 -> { plugin.toggleVanish(admin); plugin.getAdminGui().openMainMenu(admin); }
            case 11 -> { plugin.toggleGodMode(admin); plugin.getAdminGui().openMainMenu(admin); }
            case 12 -> { 
                admin.setAllowFlight(!admin.getAllowFlight()); 
                admin.setFlying(admin.getAllowFlight()); 
                admin.playSound(admin.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1f, 1f); 
                plugin.getAdminGui().openMainMenu(admin);
            }
            case 13 -> { 
                admin.setGameMode(admin.getGameMode() == GameMode.CREATIVE ? GameMode.SPECTATOR : GameMode.CREATIVE); 
                plugin.getAdminGui().openMainMenu(admin);
            }
            case 14 -> { 
                plugin.getItemManager().giveAllArtifacts(admin); 
                admin.playSound(admin.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f); 
            }
            case 15 -> { plugin.toggleLockdown(); plugin.getAdminGui().openMainMenu(admin); }
            case 16 -> { 
                for (Entity e : admin.getWorld().getEntitiesByClass(Monster.class)) e.remove();
                admin.playSound(admin.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 2f);
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getInventory().getHolder() instanceof AdminGui.AdminMenuHolder) {
            plugin.getAdminGui().removeGui((Player) event.getPlayer());
        }
    }
}
