package com.example.admincore.animation;

import com.example.admincore.AdminCore;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class SpaceAnimationManager {
    private final AdminCore plugin;
    private double t = 0;

    public SpaceAnimationManager(AdminCore plugin) {
        this.plugin = plugin;
    }

    public void startAnimations() {
        new BukkitRunnable() {
            @Override
            public void run() {
                t += Math.PI / 16;
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (plugin.getAdminGui().hasGuiOpen(player)) {
                        animateGalaxy(player);
                    }
                    if (plugin.getGodModeAdmins().contains(player.getUniqueId())) {
                        animateAura(player);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private void animateGalaxy(Player p) {
        Location loc = p.getLocation().add(0, 1, 0);
        // Double helix / Galaxy spiral
        double x1 = 1.5 * Math.cos(t);
        double z1 = 1.5 * Math.sin(t);
        double y1 = Math.sin(t / 2);
        
        double x2 = 1.5 * Math.cos(t + Math.PI);
        double z2 = 1.5 * Math.sin(t + Math.PI);
        double y2 = Math.sin((t + Math.PI) / 2);

        p.spawnParticle(Particle.PORTAL, loc.clone().add(x1, y1, z1), 2, 0, 0, 0, 0);
        p.spawnParticle(Particle.END_ROD, loc.clone().add(x2, y2, z2), 1, 0, 0, 0, 0.01);
        
        // Occasional shooting star (Meteor)
        if (Math.random() < 0.05) {
            Location meteor = loc.clone().add(Math.random()*10-5, 5, Math.random()*10-5);
            p.spawnParticle(Particle.FIREWORK, meteor, 5, 0.2, 0.2, 0.2, 0.1);
        }
    }

    private void animateAura(Player p) {
        Location loc = p.getLocation().add(0, 0.1, 0);
        double x = 1.2 * Math.cos(t * 2);
        double z = 1.2 * Math.sin(t * 2);
        p.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc.clone().add(x, 0, z), 1, 0,0,0, 0);
    }
}
