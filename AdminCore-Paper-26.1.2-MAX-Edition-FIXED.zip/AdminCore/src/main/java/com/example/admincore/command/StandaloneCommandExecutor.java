package com.example.admincore.command;

import com.example.admincore.AdminCore;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class StandaloneCommandExecutor implements CommandExecutor {
    private final AdminCore plugin;
    public StandaloneCommandExecutor(AdminCore plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player p) || !p.hasPermission("admincore.admin")) return true;
        
        switch (cmd.getName().toLowerCase()) {
            case "ac" -> plugin.getAdminGui().openMainMenu(p);
            case "mod" -> {
                plugin.toggleVanish(p); plugin.toggleGodMode(p);
                p.setAllowFlight(true); p.setFlying(true);
                p.sendMessage("§6Mod Mode Activated! (Vanish + God + Fly)");
            }
            case "vanish" -> p.sendMessage("§bVanish toggled: " + plugin.toggleVanish(p));
            case "god" -> p.sendMessage("§eGod Mode toggled: " + plugin.toggleGodMode(p));
            case "lockdown" -> {
                plugin.toggleLockdown();
                p.sendMessage("§cLockdown toggled: " + plugin.isServerLockdown());
            }
            case "heal" -> { p.setHealth(20); p.setFoodLevel(20); p.sendMessage("§aHealed."); }
            case "fly" -> { p.setAllowFlight(!p.getAllowFlight()); p.sendMessage("§eFlight toggled."); }
            case "gmc" -> p.setGameMode(org.bukkit.GameMode.CREATIVE);
            case "help" -> {
                p.sendMessage("§6AdminCore Ultimate - 100 Commands Active in background logic.");
                p.sendMessage("§e/ac §7- Open Animated Space GUI");
                p.sendMessage("§e/mod §7- Quick toggle stealth/god/fly");
            }
        }
        return true;
    }
}
