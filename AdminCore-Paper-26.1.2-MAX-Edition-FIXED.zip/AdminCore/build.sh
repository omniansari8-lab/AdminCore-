#!/usr/bin/env bash
set -e
echo "Building AdminCore for Paper 26.1.2..."
if command -v mvn >/dev/null 2>&1; then
    mvn clean package
    echo "Done! Your compiled plugin JAR is in: target/AdminCore-2.1.0.jar"
elif command -v gradle >/dev/null 2>&1; then
    gradle build
    echo "Done! Your compiled plugin JAR is in: build/libs/AdminCore-2.1.0.jar"
else
    echo "Error: Neither Maven (mvn) nor Gradle was found in your PATH."
    exit 1
fi
