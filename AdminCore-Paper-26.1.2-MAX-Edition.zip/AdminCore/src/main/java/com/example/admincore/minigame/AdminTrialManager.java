package com.example.admincore.minigame;

import com.example.admincore.AdminCore;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class AdminTrialManager {

    private final AdminCore plugin;
    private final Set<UUID> activeTrialMobs = new HashSet<>();
    private BossBar trialBossBar;
    private Location arenaCenter;
    private int currentWave = 0;
    private int totalWaves = 3;
    private int mobsPerWave = 5;
    private boolean active = false;

    public AdminTrialManager(AdminCore plugin) {
        this.plugin = plugin;
    }

    public void startTrial(Location center) {
        if (this.active) {
            stopTrial(false);
        }
        this.arenaCenter = center.clone();
        this.totalWaves = plugin.getConfig().getInt("trial-arena.total-waves", 3);
        this.mobsPerWave = plugin.getConfig().getInt("trial-arena.mob-count-per-wave", 5);
        this.currentWave = 1;
        this.active = true;

        this.trialBossBar = BossBar.bossBar(
                Component.text("⚔ Admin Trial Arena - Wave 1/" + totalWaves, NamedTextColor.RED)
                        .decoration(TextDecoration.BOLD, true),
                1.0f,
                BossBar.Color.RED,
                BossBar.Overlay.NOTCHED_10
        );

        for (Player online : Bukkit.getOnlinePlayers()) {
            online.showBossBar(this.trialBossBar);
        }

        Bukkit.broadcast(plugin.parseMessage("<gold><bold>An Admin Boss Trial has begun! Clear all " + totalWaves + " waves!</bold></gold>"));
        spawnWave();
    }

    private void spawnWave() {
        World world = arenaCenter.getWorld();
        if (world == null) {
            stopTrial(false);
            return;
        }

        activeTrialMobs.clear();
        world.playSound(arenaCenter, Sound.EVENT_RAID_HORN, 2.0f, 1.0f);
        world.spawnParticle(Particle.TRIAL_SPAWNER_DETECTION, arenaCenter, 80, 3.0, 1.0, 3.0, 0.05);

        for (int i = 0; i < mobsPerWave; i++) {
            double offsetX = ThreadLocalRandom.current().nextDouble(-4.0, 4.0);
            double offsetZ = ThreadLocalRandom.current().nextDouble(-4.0, 4.0);
            Location spawnLoc = arenaCenter.clone().add(offsetX, 0.5, offsetZ);

            Zombie mob = (Zombie) world.spawnEntity(spawnLoc, EntityType.ZOMBIE);
            mob.customName(Component.text("Trial Sentinel [Wave " + currentWave + "]", NamedTextColor.DARK_RED)
                    .decoration(TextDecoration.BOLD, true));
            mob.setCustomNameVisible(true);
            mob.setAdult();
            mob.getEquipment().setHelmet(new ItemStack(Material.NETHERITE_HELMET));
            mob.getEquipment().setItemInMainHand(new ItemStack(Material.IRON_SWORD));
            activeTrialMobs.add(mob.getUniqueId());
        }

        updateBossBar();
    }

    public void handleEntityDeath(LivingEntity entity) {
        if (!active || !activeTrialMobs.remove(entity.getUniqueId())) {
            return;
        }

        if (activeTrialMobs.isEmpty()) {
            if (currentWave < totalWaves) {
                currentWave++;
                Bukkit.broadcast(plugin.parseMessage("<yellow>Wave cleared! Spawning Wave <bold>" + currentWave + "/" + totalWaves + "</bold>!</yellow>"));
                spawnWave();
            } else {
                Bukkit.broadcast(plugin.parseMessage("<green><bold>VICTORY! All Admin Trial waves have been conquered!</bold></green>"));
                if (arenaCenter != null && arenaCenter.getWorld() != null) {
                    arenaCenter.getWorld().playSound(arenaCenter, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.5f, 1.0f);
                }
                stopTrial(false);
            }
        } else {
            updateBossBar();
        }
    }

    private void updateBossBar() {
        if (trialBossBar == null) {
            return;
        }
        float progress = Math.max(0.0f, Math.min(1.0f, (float) activeTrialMobs.size() / (float) mobsPerWave));
        trialBossBar.progress(progress);
        trialBossBar.name(Component.text(
                "⚔ Admin Trial Arena - Wave " + currentWave + "/" + totalWaves + " (" + activeTrialMobs.size() + " left)",
                NamedTextColor.RED
        ).decoration(TextDecoration.BOLD, true));
    }

    public void stopTrial(boolean announce) {
        if (!active) {
            return;
        }
        this.active = false;
        for (UUID mobId : activeTrialMobs) {
            Entity entity = Bukkit.getEntity(mobId);
            if (entity != null) {
                entity.remove();
            }
        }
        activeTrialMobs.clear();

        if (this.trialBossBar != null) {
            for (Player online : Bukkit.getOnlinePlayers()) {
                online.hideBossBar(this.trialBossBar);
            }
            this.trialBossBar = null;
        }

        if (announce) {
            Bukkit.broadcast(plugin.parseMessage("<red>The Admin Boss Trial was terminated by an Administrator.</red>"));
        }
    }

    public boolean isActive() {
        return active;
    }
}
