package com.example.admincore.listener;

import com.example.admincore.AdminCore;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.util.Vector;

public class AdminListener implements Listener {
    private final AdminCore plugin;
    public AdminListener(AdminCore plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (!p.hasPermission("admincore.admin")) return;
        String id = plugin.getItemManager().getArtifactId(e.getItem());
        if (id == null) return;
        
        if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            e.setCancelled(true);
            if (id.equals("smite")) {
                Location loc = p.getTargetBlockExact(100, FluidCollisionMode.NEVER).getLocation();
                p.getWorld().strikeLightning(loc);
            } else if (id.equals("phase")) {
                Location loc = p.getTargetBlockExact(100, FluidCollisionMode.NEVER).getLocation().add(0,1,0);
                loc.setYaw(p.getYaw()); loc.setPitch(p.getPitch());
                p.teleport(loc);
                p.playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
            } else if (id.equals("gravity")) {
                for (Entity ent : p.getNearbyEntities(10, 10, 10)) {
                    ent.setVelocity(new Vector(0, 1.5, 0));
                }
                p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 50, 5, 0, 5, 0.1);
            }
        }
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p && p.hasPermission("admincore.admin")) {
            String id = plugin.getItemManager().getArtifactId(p.getInventory().getItemInMainHand());
            if ("banish".equals(id)) {
                e.getEntity().remove();
                p.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, e.getEntity().getLocation(), 1);
            } else if ("supernova".equals(id)) {
                e.getEntity().getWorld().createExplosion(e.getEntity().getLocation(), 4f, false, false, p);
            }
        }
    }

    @EventHandler
    public void onArrowHit(ProjectileHitEvent e) {
        if (e.getEntity() instanceof Arrow arrow && arrow.getShooter() instanceof Player p) {
            String id = plugin.getItemManager().getArtifactId(p.getInventory().getItemInMainHand());
            if ("blackhole".equals(id) && e.getHitBlock() != null) {
                Location loc = e.getHitBlock().getLocation();
                loc.getWorld().spawnParticle(Particle.PORTAL, loc, 200, 3, 3, 3, 1);
                loc.getWorld().playSound(loc, Sound.BLOCK_END_PORTAL_SPAWN, 2f, 0.5f);
                for (Entity ent : loc.getWorld().getNearbyEntities(loc, 15, 15, 15)) {
                    if (!ent.equals(p)) {
                        Vector dir = loc.toVector().subtract(ent.getLocation().toVector()).normalize().multiply(1.5);
                        ent.setVelocity(dir);
                    }
                }
                arrow.remove();
            }
        }
    }

    @EventHandler
    public void onDamageReceive(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            if (plugin.getGodModeAdmins().contains(p.getUniqueId())) {
                e.setCancelled(true);
            }
            if (p.isBlocking() && "nebula".equals(plugin.getItemManager().getArtifactId(p.getInventory().getItemInOffHand()))) {
                e.setCancelled(true);
                p.getWorld().spawnParticle(Particle.SONIC_BOOM, p.getLocation().add(0,1,0), 1);
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!e.getPlayer().hasPermission("admincore.admin") && plugin.isServerLockdown()) {
            e.getPlayer().kick(Component.text("Server is in Admin Lockdown."));
        }
    }
}
