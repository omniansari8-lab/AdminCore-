package com.example.admincore.command;

import com.example.admincore.AdminCore;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AdminCommand implements CommandExecutor, TabCompleter {

    private final AdminCore plugin;

    public AdminCommand(AdminCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("admincore.admin")) {
            sender.sendMessage(plugin.parseMessage("<red>Access Denied: Requires permission <bold>admincore.admin</bold>.</red>"));
            return true;
        }

        if (args.length == 0) {
            if (sender instanceof Player admin) {
                plugin.getAdminGui().openMainMenu(admin);
            } else {
                sender.sendMessage(plugin.parseMessage("<yellow>Usage: /" + label + " <gui|item|vanish|god|freeze|lockdown|arena|reload></yellow>"));
            }
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "gui" -> {
                if (!(sender instanceof Player admin)) {
                    sender.sendMessage(plugin.parseMessage("<red>Only in-game admins can open the GUI.</red>"));
                    return true;
                }
                plugin.getAdminGui().openMainMenu(admin);
            }
            case "vanish" -> {
                if (!(sender instanceof Player admin)) {
                    sender.sendMessage(plugin.parseMessage("<red>Only in-game admins can toggle vanish.</red>"));
                    return true;
                }
                plugin.toggleVanish(admin);
            }
            case "god" -> {
                if (!(sender instanceof Player admin)) {
                    sender.sendMessage(plugin.parseMessage("<red>Only in-game admins can toggle god mode.</red>"));
                    return true;
                }
                plugin.toggleGodMode(admin);
            }
            case "item" -> {
                if (!(sender instanceof Player admin)) {
                    sender.sendMessage(plugin.parseMessage("<red>Only in-game admins can receive items.</red>"));
                    return true;
                }
                String type = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "all";
                switch (type) {
                    case "staff" -> admin.getInventory().addItem(plugin.getItemManager().createLightningStaff());
                    case "mace" -> admin.getInventory().addItem(plugin.getItemManager().createBanishCleaver());
                    case "orb" -> admin.getInventory().addItem(plugin.getItemManager().createBlinkOrb());
                    default -> admin.getInventory().addItem(
                            plugin.getItemManager().createLightningStaff(),
                            plugin.getItemManager().createBanishCleaver(),
                            plugin.getItemManager().createBlinkOrb()
                    );
                }
                admin.sendMessage(plugin.parseMessage("<green>Granted Admin Artifact(s): <bold>" + type.toUpperCase(Locale.ROOT) + "</bold>.</green>"));
            }
            case "freeze" -> {
                if (args.length < 2) {
                    sender.sendMessage(plugin.parseMessage("<red>Usage: /" + label + " freeze <player></red>"));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage(plugin.parseMessage("<red>Player not found: " + args[1] + "</red>"));
                    return true;
                }
                boolean frozen = plugin.toggleFreeze(target);
                sender.sendMessage(plugin.parseMessage(frozen
                        ? "<gold>Froze player <bold>" + target.getName() + "</bold>.</gold>"
                        : "<green>Unfroze player <bold>" + target.getName() + "</bold>.</green>"));
            }
            case "lockdown" -> {
                boolean locked = plugin.toggleLockdown();
                Bukkit.broadcast(plugin.parseMessage(locked
                        ? "<red><bold>Server Lockdown has been ENABLED by an Administrator!</bold></red>"
                        : "<green><bold>Server Lockdown has been LIFTED!</bold></green>"));
            }
            case "arena" -> {
                if (!(sender instanceof Player admin)) {
                    sender.sendMessage(plugin.parseMessage("<red>Only in-game admins can control the Trial Arena.</red>"));
                    return true;
                }
                String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "start";
                if (action.equals("stop")) {
                    plugin.getTrialManager().stopTrial(true);
                } else {
                    plugin.getTrialManager().startTrial(admin.getLocation());
                }
            }
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage(plugin.parseMessage("<green>AdminCore configuration reloaded.</green>"));
            }
            default -> sender.sendMessage(plugin.parseMessage("<yellow>Usage: /" + label + " <gui|item|vanish|god|freeze|lockdown|arena|reload></yellow>"));
        }

        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission("admincore.admin")) {
            return List.of();
        }
        if (args.length == 1) {
            return filter(List.of("gui", "item", "vanish", "god", "freeze", "lockdown", "arena", "reload"), args[0]);
        }
        if (args.length == 2) {
            return switch (args[0].toLowerCase(Locale.ROOT)) {
                case "item" -> filter(List.of("staff", "mace", "orb", "all"), args[1]);
                case "arena" -> filter(List.of("start", "stop"), args[1]);
                case "freeze" -> filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
                default -> List.of();
            };
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        List<String> matches = new ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase(Locale.ROOT).startsWith(lower)) {
                matches.add(option);
            }
        }
        return matches;
    }
}
